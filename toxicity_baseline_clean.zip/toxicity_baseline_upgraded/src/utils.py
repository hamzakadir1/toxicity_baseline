import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from pathlib import Path
from sklearn.metrics import (
    roc_auc_score,
    average_precision_score,
    roc_curve,
    precision_recall_curve,
)
from sklearn.calibration import calibration_curve

def save_metrics_csv(path_csv: Path, record: dict):
    path_csv.parent.mkdir(parents=True, exist_ok=True)
    try:
        df_old = pd.read_csv(path_csv)
        df = pd.concat([df_old, pd.DataFrame([record])], ignore_index=True)
    except Exception:
        df = pd.DataFrame([record])
    df.to_csv(path_csv, index=False)

def plot_curves(y_true, y_prob, out_roc: Path, out_pr: Path):
    # ROC
    fpr, tpr, _ = roc_curve(y_true, y_prob)
    plt.figure()
    plt.plot(fpr, tpr, label="ROC")
    plt.plot([0, 1], [0, 1], "--")
    plt.xlabel("FPR")
    plt.ylabel("TPR")
    plt.title("ROC Curve")
    plt.legend()
    plt.tight_layout()
    plt.savefig(out_roc)
    plt.close()

    # PR
    precision, recall, _ = precision_recall_curve(y_true, y_prob)
    plt.figure()
    plt.step(recall, precision, where="post", label="PR")
    plt.xlabel("Recall")
    plt.ylabel("Precision")
    plt.title("PR Curve")
    plt.legend()
    plt.tight_layout()
    plt.savefig(out_pr)
    plt.close()

def plot_calibration(y_true, y_prob, out_path: Path):
    prob_true, prob_pred = calibration_curve(y_true, y_prob, n_bins=10, strategy="quantile")
    plt.figure()
    plt.plot([0, 1], [0, 1], "--", label="Perfectly calibrated")
    plt.plot(prob_pred, prob_true, marker="o", label="Model")
    plt.xlabel("Predicted probability")
    plt.ylabel("Observed frequency")
    plt.title("Calibration (Reliability) Curve")
    plt.legend()
    plt.tight_layout()
    plt.savefig(out_path)
    plt.close()

def load_dataframe(csv_path: str, id_col: str, label_col: str, feature_cols):
    df = pd.read_csv(csv_path)
    assert id_col in df.columns, f"Missing id_col: {id_col}"
    assert label_col in df.columns, f"Missing label_col: {label_col}"
    if feature_cols in (None, "auto"):
        # numeric features excluding id/label
        feats = [c for c in df.columns if c not in [id_col, label_col]]
        df_num = df[feats].select_dtypes(include=[np.number])
        feats = list(df_num.columns)
    else:
        feats = feature_cols
        for c in feats:
            assert c in df.columns, f"Feature column not found: {c}"
    return df, feats

def summarize_class_balance(y):
    y = np.asarray(y).astype(int)
    pos_rate = float((y == 1).mean())
    print(f"[INFO] Positive rate: {pos_rate:.3f}  (neg={1-pos_rate:.3f}, pos={pos_rate:.3f})")
