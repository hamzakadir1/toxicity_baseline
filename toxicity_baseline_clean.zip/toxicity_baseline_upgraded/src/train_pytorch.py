import argparse, json, random
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from pathlib import Path
from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import roc_auc_score, average_precision_score

from utils import (
    save_metrics_csv,
    plot_curves,
    plot_calibration,
    load_dataframe,
    summarize_class_balance,
)

def set_seed(s):
    random.seed(s)
    np.random.seed(s)
    torch.manual_seed(s)
    torch.cuda.manual_seed_all(s)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

class MLP(nn.Module):
    def __init__(self, in_dim, hidden=128, dropout=0.1):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(in_dim, hidden),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden, hidden // 2),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden // 2, 1),
        )

    def forward(self, x):
        return self.net(x).squeeze(-1)

def main(a):
    set_seed(a.seed)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    out_metrics = Path("results/metrics.csv")
    out_config  = Path("results/config_last.json")

    df, feat_cols = load_dataframe(a.data_csv, a.id_col, a.label_col, a.features)
    X = df[feat_cols].values.astype(np.float32)
    y = df[a.label_col].values.astype(np.float32)

    summarize_class_balance(y)

    # Standardize features for MLP stability
    X_mean = X.mean(axis=0, keepdims=True)
    X_std  = X.std(axis=0, keepdims=True) + 1e-8
    X = (X - X_mean) / X_std

    skf = StratifiedKFold(n_splits=a.kfold, shuffle=True, random_state=a.seed)
    oof_prob = np.zeros_like(y, dtype=np.float32)

    in_dim = X.shape[1]
    for tr, te in skf.split(X, y):
        Xtr, Xte = X[tr], X[te]
        ytr, yte = y[tr], y[te]

        model = MLP(in_dim, hidden=a.hidden, dropout=a.dropout).to(device)
        crit  = nn.BCEWithLogitsLoss()
        opt   = optim.Adam(model.parameters(), lr=a.lr, weight_decay=a.weight_decay)

        Xtr_t = torch.tensor(Xtr, device=device)
        ytr_t = torch.tensor(ytr, device=device)
        Xte_t = torch.tensor(Xte, device=device)

        for _ in range(a.epochs):
            model.train()
            opt.zero_grad()
            logits = model(Xtr_t)
            loss = crit(logits, ytr_t)
            loss.backward()
            opt.step()

        model.eval()
        with torch.no_grad():
            prob = torch.sigmoid(model(Xte_t)).cpu().numpy()
        oof_prob[te] = prob

    roc = roc_auc_score(y, oof_prob)
    pr  = average_precision_score(y, oof_prob)

    rec = {
        "framework": "pytorch",
        "model": "mlp",
        "kfold": a.kfold,
        "seed": a.seed,
        "epochs": a.epochs,
        "hidden": a.hidden,
        "dropout": a.dropout,
        "lr": a.lr,
        "weight_decay": a.weight_decay,
        "roc_auc": round(float(roc), 4),
        "pr_auc": round(float(pr), 4),
        "data_csv": a.data_csv,
        "features": "auto" if a.features in (None, "auto") else ",".join(a.features),
    }
    print(rec)
    save_metrics_csv(out_metrics, rec)
    plot_curves(y_true=y, y_prob=oof_prob, out_roc=Path("plots/roc_curve.png"), out_pr=Path("plots/pr_curve.png"))
    plot_calibration(y_true=y, y_prob=oof_prob, out_path=Path("plots/calibration.png"))
    out_config.write_text(json.dumps(vars(a), indent=2))

if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--data_csv", type=str, required=True)
    p.add_argument("--id_col", type=str, default="id")
    p.add_argument("--label_col", type=str, default="y")
    p.add_argument("--features", nargs="+", default="auto")
    p.add_argument("--kfold", type=int, default=5)
    p.add_argument("--epochs", type=int, default=50)
    p.add_argument("--hidden", type=int, default=128)
    p.add_argument("--dropout", type=float, default=0.1)
    p.add_argument("--lr", type=float, default=1e-3)
    p.add_argument("--weight_decay", type=float, default=1e-4)
    p.add_argument("--seed", type=int, default=42)
    a = p.parse_args()
    if a.features == ["auto"]: a.features = "auto"
    main(a)
