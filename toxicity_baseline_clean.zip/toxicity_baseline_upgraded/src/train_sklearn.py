import argparse, json
import numpy as np
from pathlib import Path
from sklearn.model_selection import StratifiedKFold
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.metrics import roc_auc_score, average_precision_score
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.ensemble import RandomForestClassifier
from sklearn.neighbors import KNeighborsClassifier

from utils import (
    save_metrics_csv,
    plot_curves,
    plot_calibration,
    load_dataframe,
    summarize_class_balance,
)

def get_models():
    return {
        "logreg": Pipeline([
            ("scaler", StandardScaler()),
            ("clf", LogisticRegression(max_iter=200, class_weight="balanced")),
        ]),
        "svm": Pipeline([
            ("scaler", StandardScaler()),
            ("clf", SVC(kernel="rbf", probability=True, class_weight="balanced")),
        ]),
        "rf": RandomForestClassifier(n_estimators=300, class_weight="balanced"),
        "knn": Pipeline([
            ("scaler", StandardScaler()),
            ("clf", KNeighborsClassifier(n_neighbors=11)),
        ]),
    }

def main(a):
    np.random.seed(a.seed)
    out_metrics = Path("results/metrics.csv")
    out_config  = Path("results/config_last.json")

    df, feat_cols = load_dataframe(a.data_csv, a.id_col, a.label_col, a.features)
    X = df[feat_cols].values
    y = df[a.label_col].values.astype(int)
    ids = df[a.id_col].values

    # Class balance + duplicate ID warning
    summarize_class_balance(y)
    dup_ids = df[a.id_col][df[a.id_col].duplicated()].unique()
    if len(dup_ids) > 0:
        print(f"[WARN] Duplicate IDs detected: {len(dup_ids)}. Ensure no ID appears in both train/test folds.")

    models = get_models()
    if not a.model_all:
        models = {a.model: models[a.model]}

    skf = StratifiedKFold(n_splits=a.kfold, shuffle=True, random_state=a.seed)

    for name, model in models.items():
        oof_prob = np.zeros_like(y, dtype=float)
        for tr, te in skf.split(X, y):
            model.fit(X[tr], y[tr])
            prob = model.predict_proba(X[te])[:, 1]
            oof_prob[te] = prob

        roc = roc_auc_score(y, oof_prob)
        pr  = average_precision_score(y, oof_prob)

        rec = {
            "framework": "sklearn",
            "model": name,
            "kfold": a.kfold,
            "seed": a.seed,
            "roc_auc": round(float(roc), 4),
            "pr_auc": round(float(pr), 4),
            "data_csv": a.data_csv,
            "features": "auto" if a.features in (None, "auto") else ",".join(a.features),
        }
        print(rec)
        save_metrics_csv(out_metrics, rec)

        # plots from latest run
        plot_curves(y_true=y, y_prob=oof_prob, out_roc=Path("plots/roc_curve.png"), out_pr=Path("plots/pr_curve.png"))
        plot_calibration(y_true=y, y_prob=oof_prob, out_path=Path("plots/calibration.png"))

    out_config.write_text(json.dumps(vars(a), indent=2))

if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--data_csv", type=str, required=True)
    p.add_argument("--id_col", type=str, default="id")
    p.add_argument("--label_col", type=str, default="y")
    p.add_argument("--features", nargs="+", default="auto")
    p.add_argument("--model", type=str, choices=["logreg","svm","rf","knn"], default="logreg")
    p.add_argument("--model_all", action="store_true")
    p.add_argument("--kfold", type=int, default=5)
    p.add_argument("--seed", type=int, default=42)
    a = p.parse_args()
    if a.features == ["auto"]: a.features = "auto"
    main(a)
