# Drug Toxicity Prediction — Baseline (sklearn vs PyTorch)

Compare classic ML (**LogReg/SVM/RF/KNN**) to a small **PyTorch MLP** for binary toxicity.  
**Stratified k-fold**, fixed seeds, **ROC-AUC & PR-AUC**, duplicate-ID leakage warning, and a **calibration curve**.

## Setup
```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
```

## Run (sample data)
```bash
# sklearn (all four)
python src/train_sklearn.py --data_csv data/sample_tox21.csv --id_col id --label_col y --model_all --kfold 5 --seed 42

# PyTorch MLP (standardized features)
python src/train_pytorch.py --data_csv data/sample_tox21.csv --id_col id --label_col y --epochs 50 --seed 42
```

Outputs: `results/metrics.csv`, `plots/roc_curve.png`, `plots/pr_curve.png`, `plots/calibration.png`, `results/config_last.json`.

## Real data
Provide a CSV with columns `id, y, f0..fN` (numeric features/fingerprints). Change `--data_csv` to your file path.
